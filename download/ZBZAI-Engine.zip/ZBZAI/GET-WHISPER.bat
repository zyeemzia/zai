@echo off
title ZBZAI - get offline voice typing (Whisper)
echo.
echo  ZBZAI can turn speech into text on this computer with Whisper, a free open
echo  speech model, so voice typing works with no internet. Do this once while online.
echo  (Without it, ZBZAI uses the speech recognition built into Windows.)
echo.
echo  Download size: about 150 MB.
echo.
set /p ok=  Download now? [Y/n]
if /i "%ok%"=="n" exit /b
set "dest=%~dp0data\whisper"
if not exist "%dest%" mkdir "%dest%"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; $d='%dest%';" ^
  "Write-Host '  Getting the Whisper program ...'; Invoke-WebRequest 'https://github.com/ggml-org/whisper.cpp/releases/latest/download/whisper-bin-x64.zip' -OutFile \"$d\whisper.zip\" -UseBasicParsing;" ^
  "Expand-Archive \"$d\whisper.zip\" -DestinationPath $d -Force; Remove-Item \"$d\whisper.zip\";" ^
  "Write-Host '  Getting the speech model (base, many languages) ...'; Invoke-WebRequest 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin' -OutFile \"$d\ggml-base.bin\" -UseBasicParsing;" ^
  "Write-Host '  Done.'"
if errorlevel 1 (
  echo.
  echo  The download did not finish. Check the internet connection and run this file again.
  pause
  exit /b 1
)
echo.
echo  Offline voice typing is ready. ZBZAI uses it at once; no restart needed.
pause
