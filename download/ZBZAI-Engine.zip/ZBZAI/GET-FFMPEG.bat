@echo off
title ZBZAI - get the media tool (ffmpeg)
echo.
echo  ZBZAI uses ffmpeg, a free open tool, to edit video, make MP3, FLAC, Opus and
echo  other sound files, and restyle pictures. Do this once while online.
echo  (Without it, ZBZAI still makes WAV sound and every office file.)
echo.
echo  Download size: about 100 MB.
echo.
set /p ok=  Download now? [Y/n]
if /i "%ok%"=="n" exit /b
set "dest=%~dp0data\tools"
if not exist "%dest%" mkdir "%dest%"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; $d='%dest%';" ^
  "Write-Host '  Getting ffmpeg ...'; Invoke-WebRequest 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -OutFile \"$d\ffmpeg.zip\" -UseBasicParsing;" ^
  "Expand-Archive \"$d\ffmpeg.zip\" -DestinationPath \"$d\ffmpeg-new\" -Force; Remove-Item \"$d\ffmpeg.zip\";" ^
  "$f = Get-ChildItem \"$d\ffmpeg-new\" -Recurse -Filter ffmpeg.exe | Select-Object -First 1; if (-not $f) { throw 'ffmpeg.exe was not in the download' };" ^
  "Copy-Item $f.FullName \"$d\ffmpeg.exe\" -Force; Remove-Item \"$d\ffmpeg-new\" -Recurse -Force;" ^
  "Write-Host '  Done.'"
if errorlevel 1 (
  echo.
  echo  The download did not finish. Check the internet connection and run this file again.
  pause
  exit /b 1
)
echo.
echo  The media tool is ready. Restart ZBZAI to use it.
pause
