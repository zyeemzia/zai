# Using ZBZAI

## Installing ZBZAI
Download ZBZAI-Setup.exe from zbzai.zyeemzia.com and run it on the computer that will be the server. If Windows says it protected your PC, choose More info, then Run anyway. Accept the licence, pick a drive or folder (the default needs no administrator rights; Program Files does), choose desktop and Start menu shortcuts, and press Install. Python is built in. On Linux or macOS, unzip ZBZAI-Engine.zip and run start-zbzai.sh with Python 3.9 or newer.

## Starting ZBZAI
Open ZBZAI from the desktop or Start menu icon. A window opens and shows two addresses: one for this computer and one for the local network, for example http://192.168.1.20:8765/, plus the admin PIN. Share the network address with anyone on the same Wi-Fi or LAN. Keep the window open while ZBZAI is in use; closing it stops the server.

## Phones, tablets and other computers
ZBZAI runs on the ZBZAI computer; other devices use it over the local network, with no internet. Connect the phone or tablet to the same Wi-Fi or network as the ZBZAI computer, open Share in ZBZAI and scan the QR code with the phone camera, or type the address. To open ZBZAI like an app: on Android in Chrome, tap the menu, then Add to Home screen or Install app; on iPhone and iPad in Safari, tap Share, then Add to Home Screen. On the ZBZAI computer itself, press Install app in the top bar (Edge or Chrome) for a ZBZAI window with its own icon. Phones cannot run ZBZAI by themselves; ZBZAI must be open on the ZBZAI computer.

The first time, Windows may ask whether ZBZAI can use the network. Choose Private networks so other devices on the LAN can connect. If others cannot connect, check that the host computer's network is set to Private and that both devices are on the same network.

## Getting a local AI model
Run GET-LOCAL-MODEL.bat once while online. It installs a free open model through Ollama. Small (qwen2.5:3b, about 2 GB) runs on most computers without a graphics card. Medium (qwen2.5:7b) gives better answers with 16 GB of memory or a graphics card. Large (qwen2.5:14b) needs a strong graphics card. After that, ZBZAI runs fully offline, and so do its coworkers. ZBZAI finds installed models automatically.

## Chatting
Type a question and press Enter. While ZBZAI answers, the send button becomes Stop. Under each answer: Copy, Read aloud, Try again, Export and Learn this. The plus button opens New chat, Past chats, Ask about a file (Word, PDF or text) and Save this chat. The microphone button types what you say, in the voice typing language chosen in Settings. It keeps listening through short pauses and stops by itself when you finish. With no internet it still works: the ZBZAI computer turns your voice into text itself, using the speech recognition built into Windows, or Whisper after you run GET-WHISPER.bat once.

## Coworkers
Open Coworkers to pick an AI coworker: Word Writer, Excel Analyst, PowerPoint Builder, Database Designer, PDF Publisher, Email and Letter Assistant, Minutes Taker, Voice Narrator, Video Explainer, Data Cleaner, Translator, HR and Policy Drafter, Tutor or IT Helpdesk. Press Work with, and the chat works in that coworker's way until you close the Working with bar. Customise makes your own copy of a ready-made coworker; New coworker creates one from scratch with a name, role, instructions, starter prompts, best export and icon. Coworkers are shared with everyone on the network and use what ZBZAI knows. They write full answers with a local model (offline) or with ZyeemZia AI online.

## Exporting files
Press Export under an answer, or in Studio, and choose a format: Word (.docx), Excel (.xlsx), PowerPoint (.pptx), PDF, Access (.accdb, needs Microsoft Office on the ZBZAI computer), CSV, SQLite database, web page, Markdown, text, JSON, audio as WAV (Windows voices) or MP3, or a narrated video as MP4 (MP3 and MP4 need the free ffmpeg tool on the ZBZAI computer). Tables become spreadsheet sheets and database tables named after the heading above them; ## headings become slides. For Bangla or Arabic PDFs, use Print and Save as PDF.

## Layouts, your own files and real conversion
Export has a Layout choice. ZBZAI style is the plain look. Service writing makes a Word or PDF file in service layout: A4, a centred and underlined subject heading, group headings in capitals, numbered paragraphs with lettered sub-paragraphs, and a security marking you type (for example RESTRICTED) at the top and bottom of every page with the page number at the foot. Your own files: in Studio, Documents, press Add a file as a format and choose a Word (.docx), Excel (.xlsx) or PowerPoint (.pptx) file. ZBZAI then writes into that very file. A Word file keeps its letterhead, header, footer, margins and styles; put [Body] where the text should go, and [Subject] and [Date] where you want them. An Excel file keeps its headings, column widths and other sheets, and new rows take the look of its sample row. A PowerPoint file keeps its design, theme and layouts, and gets new slides. Convert a file to PDF, also in Studio, turns Word, Excel and PowerPoint files into PDF with the layout, pictures and letterhead kept, and PDF or old file to Word turns an old document into a Word file with its layout, or a PDF into a Word file with its text. Keeping the layout uses Microsoft Office or the free LibreOffice on the ZBZAI computer; without either, only the text is converted and ZBZAI says so. Sound can be saved as MP3, WAV, M4A, FLAC, Opus, OGG or AAC in Studio, Video, Convert. Video and these sound formats need the free ffmpeg tool: run GET-FFMPEG.bat once on the ZBZAI computer while online.

## Live internet lookup
When a question is about something recent (the latest news, today, a current office holder, a recent year) or asks to search the internet, ZBZAI looks it up first on public news feeds and an encyclopedia, then answers with dates and named sources. What it finds is kept in the knowledge vault under a title starting with Internet, so the same answer is there later with no internet. The same question is looked up once in half an hour, and the vault keeps the newest 300 lookups. It needs an internet connection; with none, ZBZAI answers as before. Turn it off in Settings: Look recent things up on the internet.

## Automate: actions on the ZBZAI computer, with permission
Open Automate to have ZBZAI do things on the ZBZAI computer. It is off until the admin turns it on with the PIN and names the folders ZBZAI may use. Write what to do, one step per line, for example: make folder Reports; move letter.docx to Reports; save this as Reports/brief.docx; open Reports; open notepad. Press Show the plan: ZBZAI lists exactly what it will do, and nothing happens until you press Allow. It can open and list folders, open and print files, make folders, copy, move and rename, send a file to the Recycle Bin, save the last answer as a Word, Excel, PowerPoint, PDF or text file, open a public website and start Notepad, Calculator, Paint, File Explorer, Word, Excel or PowerPoint. It cannot do anything else: it never opens programs, scripts or shortcuts, never overwrites a file, and never touches anything outside the allowed folders. From a phone or another computer on the network, every request needs the admin PIN; on the ZBZAI computer itself only deleting and printing do. A routine is a saved list of steps you run with one tap, and it still asks for permission each time. Every action is written to a log the admin can read.

## Real pictures in answers
Ask for a picture, photo or image of something and ZBZAI shows up to three real pictures above its answer. It finds them in the free media library Wikimedia Commons, copies them to the ZBZAI computer so they still show later with no internet, and names each maker, its licence and its source page. It never makes up a picture link, and it says so when no free picture is found. To have a new picture made, use Studio, Pictures. It needs an internet connection and follows the same Settings switch as the internet lookup.

## Teaching ZBZAI
Open Knowledge. Paste notes, procedures, manuals or facts and press Teach, or upload files: text, Markdown, CSV, JSON, HTML, Word (.docx) and PDF. Tick "This is a document format" to add a letter or memo layout to Studio's Template list. When an answer is good, press Learn this: ZBZAI keeps it and uses it in future answers. That is how ZBZAI becomes smarter day by day.

## ZBZAI Studio
Documents: choose a template or one of your own formats, fill in the fields and press Write it; edit, copy, print, save as Word or export in any format. Quick draft fills the template instantly with no AI. Save as my format turns any document into a template. Pictures: describe a picture, pick a style and press Create; made free online by ZyeemZia AI, or offline with a local Stable Diffusion, and kept in a shared gallery. Songs: give a topic, language, mood and style for an original song with chords.

## Settings and the admin PIN
The admin PIN is needed to change settings, remove knowledge, formats, coworkers or pictures, and for backup, restore and reset. After several wrong PINs in a row ZBZAI pauses PIN entry from that device for a minute, and it refuses changes sent by other websites. The administrator can limit teaching to the admin only. Appearance (theme, accent colour, text size, voice typing language, read-aloud speed, wide layout) is set per device.

## Online answers, free
When the computer is online and no local model is installed, ZBZAI answers with ZyeemZia AI for free, grounded in its knowledge vault. When the internet is unavailable, it switches back to the local model or the vault automatically. More brains are optional: Claude, ChatGPT, Gemini, DeepSeek, Groq, Mistral, Grok and OpenRouter. In Settings, open "more AI brains with your own keys", paste the key, choose that brain and save. A brain with a key also answers when the chosen one cannot, for example when the free allowance is used up. When online, ZBZAI also keeps an offline copy of the ZyeemZia AI knowledge library (public facts about the ZyeemZia sites) so answers know them with no internet; it refreshes by itself, is kept apart from what you taught, and can be switched off in Settings.

## Updating ZBZAI
When a new version is available, a banner appears. Open Settings, enter the admin PIN and press Update now; ZBZAI downloads the update, checks its fingerprint, installs it and restarts. Running a newer ZBZAI-Setup.exe also updates ZBZAI. Knowledge, conversations, formats, coworkers and settings are always kept.

## Backup, restore and reset
Settings, Backup and restore: Back up now saves one file with everything; download it to keep a copy elsewhere. ZBZAI also backs up automatically every day and keeps the last seven. Restore works from the list or from an uploaded backup file. Reset options clear conversations, restore default settings, return to the starter knowledge, or reset everything; a safety backup is made first, so every change can be undone.

## Uninstalling
Use Apps in Windows Settings, or Uninstall ZBZAI in the ZBZAI folder. You can keep what ZBZAI learned so a later install picks it up again.
