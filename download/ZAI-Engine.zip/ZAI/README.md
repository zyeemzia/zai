# ZAI · ZyeemZia offline LAN AI engine

Turn one Windows computer into a private AI server for your whole local network.
No internet, no accounts, nothing leaves the building. Free, by ZyeemZia.

## Start in one click
1. Install Python 3 from python.org (tick **Add python.exe to PATH**), if it is not installed yet.
2. Double-click **START-ZAI.bat**.
3. The window shows the network address, for example `http://192.168.1.20:8765/`.
   Anyone on the same Wi-Fi or LAN opens it in a browser and uses ZAI.

If Windows asks about the firewall, allow **Private networks**.

## Brains (chosen automatically)
| Brain | Needs | Notes |
|---|---|---|
| Local model | Ollama + a model (run **GET-LOCAL-MODEL.bat** once while online) | Fully offline afterwards. Best for private LANs. |
| ZyeemZia AI | Internet | Free, no key. Used when online and no local model is installed. |
| Claude (optional) | Internet + your own paid Anthropic API key (run **ENABLE-CLOUD.bat** once, add the key in Settings) | Only when chosen in Settings. |
| Knowledge vault | Nothing | Answers straight from what ZAI has learned. Always available. |

If a brain fails, ZAI falls back to the next one by itself.

## Smart updates
When online, ZAI checks zai.zyeemzia.com for new versions. Press **Update now** in Settings (admin PIN): it downloads, verifies the fingerprint, replaces the program files and restarts. The `data` folder is never touched.

## ZAI Studio
- **Documents**: letters, leave applications, emails, notices, reports, minutes, certificates, cover letters. Fill the fields and press **Write it**; copy, print or save as Word. **Quick draft** works with no AI.
- **Pictures**: free online through ZyeemZia AI. For offline pictures, run a local Stable Diffusion WebUI or Forge on this PC with its API enabled (`--api`, port 7860); ZAI uses it automatically. Pictures are saved in `data/images` and shared in the gallery.
- **Songs**: original lyrics with chords, key, tempo and strumming, in many languages and styles. Audio is not generated.

## How ZAI grows
ZAI learns through its **knowledge vault** (retrieval-augmented generation):
- **Knowledge → Teach**: paste notes, procedures, manuals, facts.
- **Knowledge → Upload**: .txt .md .csv .json .html .docx, and .pdf after **ENABLE-EXTRAS.bat**.
- **👍 Learn this** on a good answer: ZAI keeps it for the future.
- Starter knowledge in the `knowledge` folder is learned on first start; add your own `.md` or `.txt` files there.

Every answer is grounded in the most relevant passages and shows its sources.

## Admin PIN
Shown in the ZAI window. Needed to change settings and to remove knowledge. Settings can also limit teaching to the admin.

## Backup and moving
Everything ZAI knows is in the `data` folder (`zai.db`, `config.json`). Copy it to back up or move ZAI to another computer.

## Requirements
Windows 10 or 11 (also runs on Linux and macOS with `sh start-zai.sh`), Python 3.9 or newer.
A local model needs about 4 GB free memory for the small model; a graphics card makes larger models fast.

Website: https://zai.zyeemzia.com

Copyright © ZyeemZia
