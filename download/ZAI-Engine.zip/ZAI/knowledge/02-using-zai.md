# Using ZAI

## Installing ZAI
Download ZAI-Setup.exe from zai.zyeemzia.com and run it on the computer that will be the server. If Windows says it protected your PC, choose More info, then Run anyway. Accept the licence, pick a drive or folder (the default needs no administrator rights; Program Files does), choose desktop and Start menu shortcuts, and press Install. Python is built in. On Linux or macOS, unzip ZAI-Engine.zip and run start-zai.sh with Python 3.9 or newer.

## Starting ZAI
Open ZAI from the desktop or Start menu icon. A window opens and shows two addresses: one for this computer and one for the local network, for example http://192.168.1.20:8765/, plus the admin PIN. Share the network address with anyone on the same Wi-Fi or LAN. Keep the window open while ZAI is in use; closing it stops the server.

The first time, Windows may ask whether ZAI can use the network. Choose Private networks so other devices on the LAN can connect. If others cannot connect, check that the host computer's network is set to Private and that both devices are on the same network.

## Getting a local AI model
Run GET-LOCAL-MODEL.bat once while online. It installs a free open model through Ollama. Small (qwen2.5:3b, about 2 GB) runs on most computers without a graphics card. Medium (qwen2.5:7b) gives better answers with 16 GB of memory or a graphics card. Large (qwen2.5:14b) needs a strong graphics card. After that, ZAI runs fully offline, and so do its coworkers. ZAI finds installed models automatically.

## Chatting
Type a question and press Enter. While ZAI answers, the send button becomes Stop. Under each answer: Copy, Read aloud, Try again, Export and Learn this. The plus button opens New chat, Past chats, Ask about a file (Word, PDF or text) and Save this chat. The microphone button types what you say, in the voice typing language chosen in Settings.

## Coworkers
Open Coworkers to pick an AI coworker: Word Writer, Excel Analyst, PowerPoint Builder, Database Designer, PDF Publisher, Email and Letter Assistant, Minutes Taker, Voice Narrator, Video Explainer, Data Cleaner, Translator, HR and Policy Drafter, Tutor or IT Helpdesk. Press Work with, and the chat works in that coworker's way until you close the Working with bar. Customise makes your own copy of a ready-made coworker; New coworker creates one from scratch with a name, role, instructions, starter prompts, best export and icon. Coworkers are shared with everyone on the network and use what ZAI knows. They write full answers with a local model (offline) or with ZyeemZia AI online.

## Exporting files
Press Export under an answer, or in Studio, and choose a format: Word (.docx), Excel (.xlsx), PowerPoint (.pptx), PDF, Access (.accdb, needs Microsoft Office on the ZAI computer), CSV, SQLite database, web page, Markdown, text, JSON, audio as WAV (Windows voices) or MP3, or a narrated video as MP4 (MP3 and MP4 need the free ffmpeg tool on the ZAI computer). Tables become spreadsheet sheets and database tables named after the heading above them; ## headings become slides. For Bangla or Arabic PDFs, use Print and Save as PDF.

## Teaching ZAI
Open Knowledge. Paste notes, procedures, manuals or facts and press Teach, or upload files: text, Markdown, CSV, JSON, HTML, Word (.docx) and PDF. Tick "This is a document format" to add a letter or memo layout to Studio's Template list. When an answer is good, press Learn this: ZAI keeps it and uses it in future answers. That is how ZAI becomes smarter day by day.

## ZAI Studio
Documents: choose a template or one of your own formats, fill in the fields and press Write it; edit, copy, print, save as Word or export in any format. Quick draft fills the template instantly with no AI. Save as my format turns any document into a template. Pictures: describe a picture, pick a style and press Create; made free online by ZyeemZia AI, or offline with a local Stable Diffusion, and kept in a shared gallery. Songs: give a topic, language, mood and style for an original song with chords.

## Settings and the admin PIN
The admin PIN is needed to change settings, remove knowledge, formats, coworkers or pictures, and for backup, restore and reset. The administrator can limit teaching to the admin only. Appearance (theme, accent colour, text size, voice typing language, read-aloud speed, wide layout) is set per device.

## Online answers, free
When the computer is online and no local model is installed, ZAI answers with ZyeemZia AI for free, grounded in its knowledge vault. When the internet is unavailable, it switches back to the local model or the vault automatically. Claude is optional: run ENABLE-CLOUD.bat once, add your own paid Anthropic API key in Settings, and choose Claude as the brain.

## Updating ZAI
When a new version is available, a banner appears. Open Settings, enter the admin PIN and press Update now; ZAI downloads the update, checks its fingerprint, installs it and restarts. Running a newer ZAI-Setup.exe also updates ZAI. Knowledge, conversations, formats, coworkers and settings are always kept.

## Backup, restore and reset
Settings, Backup and restore: Back up now saves one file with everything; download it to keep a copy elsewhere. ZAI also backs up automatically every day and keeps the last seven. Restore works from the list or from an uploaded backup file. Reset options clear conversations, restore default settings, return to the starter knowledge, or reset everything; a safety backup is made first, so every change can be undone.

## Uninstalling
Use Apps in Windows Settings, or Uninstall ZAI in the ZAI folder. You can keep what ZAI learned so a later install picks it up again.
