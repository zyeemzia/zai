# Using ZAI

## Starting ZAI
Double-click START-ZAI.bat. A window opens and shows two addresses: one for this computer and one for the local network, for example http://192.168.1.20:8765/. Share the network address with anyone on the same Wi-Fi or LAN. Keep the window open while ZAI is in use; closing it stops the server.

The first time, Windows may ask whether Python can use the network. Choose Private networks so other devices on the LAN can connect. If others cannot connect, check that the host computer's network is set to Private and that both devices are on the same network.

## Getting a local AI model
Run GET-LOCAL-MODEL.bat once while online. It installs a free open model through Ollama. Small (qwen2.5:3b, about 2 GB) runs on most computers without a graphics card. Medium (qwen2.5:7b) gives better answers with 16 GB of memory or a graphics card. Large (qwen2.5:14b) needs a strong graphics card. After that, ZAI runs fully offline. ZAI finds installed models automatically.

## Teaching ZAI
Open Knowledge in the ZAI page. Paste notes, procedures, manuals or facts and press Teach, or upload files: text, Markdown, CSV, JSON, HTML, Word (.docx), and PDF after running ENABLE-EXTRAS.bat once. When an answer is good, press the thumbs-up: ZAI keeps it and uses it in future answers. That is how ZAI becomes smarter day by day.

## ZAI Studio
Open Studio for three tools. Documents: choose a template (official letter, leave application, professional email, notice, report, meeting minutes, certificate of appreciation, cover letter), fill in the fields and press Write it; the text can be edited, copied, printed or saved as a Word file. Quick draft makes the document from the template instantly, even with no AI. Pictures: describe a picture, pick a style and press Create; pictures are made free online by ZyeemZia AI, or offline when a local Stable Diffusion is running on the ZAI computer, and are kept in a gallery shared on the network. Songs: give a topic, language, mood and style, and ZAI writes an original song with chords, key, tempo and strumming. Teach ZAI your letterhead and writing style in Knowledge and Studio follows them.

## Settings and the admin PIN
The ZAI window shows an admin PIN. It is needed to change settings and to remove knowledge, so ordinary users cannot break anything. The administrator can also limit teaching to the admin only.

## Online answers, free
When the computer is online and no local model is installed, ZAI answers with ZyeemZia AI for free, grounded in its knowledge vault. When the internet is unavailable, it switches back to the local model or the vault automatically. Claude is optional: run ENABLE-CLOUD.bat once, add your own paid Anthropic API key in Settings, and choose Claude as the brain.

## Updating ZAI
When a new version is available, a banner appears. Open Settings, enter the admin PIN and press Update now. ZAI downloads the update, checks its fingerprint, installs it and restarts. Knowledge, conversations and settings are kept.

## Backup
Everything ZAI knows is in the data folder: zai.db holds the knowledge and conversations, config.json the settings. Copy the data folder to back up or move ZAI.
