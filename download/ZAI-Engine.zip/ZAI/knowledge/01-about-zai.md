# About ZAI

ZAI is the ZyeemZia offline LAN AI engine, made by ZyeemZia and free for everyone. It turns one Windows computer into a private AI server for a whole office, school, unit or home network. ZAI runs on that computer only; phones, tablets and other computers on the same local network use it in the browser by scanning the QR code in the Share tab or opening the address shown in the ZAI window, with no internet and no accounts, and can add it to their home screen as an app. Phones do not run ZAI on their own: the ZAI computer must be switched on with ZAI open.

ZAI installs from one file, ZAI-Setup.exe, which carries its own Python, so nothing else needs installing. Setup lets you choose the drive and folder, adds desktop and Start menu icons and an entry in Apps with a clean uninstaller, and needs no administrator rights. Running a newer setup updates ZAI in place; on first install it even brings over what an earlier ZAI on the same computer had learned.

ZAI has three free brains and chooses the best one available automatically. The local brain is an open AI model running on the host computer through Ollama; it is fully offline after the model is downloaded once. The online brain is ZyeemZia AI, free with no key, used when the internet is available. The vault brain needs no model at all: it answers straight from the knowledge ZAI has learned. Claude can be added as an optional extra with your own paid API key.

ZAI does real office work. Studio writes letters and documents from templates or your own formats, creates pictures and writes songs. Coworkers are AI assistants for every kind of office task: fourteen are ready-made (Word writer, Excel analyst, PowerPoint builder, database designer, PDF publisher, email and letter assistant, minutes taker, voice narrator, video explainer, data cleaner, translator, HR and policy drafter, tutor and IT helpdesk), and anyone can create their own. Every answer and document exports to Word, Excel, PowerPoint, PDF, Access, CSV, a SQLite database, a web page, Markdown, text and JSON, and to spoken audio (WAV, or MP3) and narrated video (MP4) when those tools are available.

ZAI grows smarter by learning. Its knowledge vault stores documents, notes and good answers. Before every answer ZAI searches the vault and gives the most relevant passages to the AI, so answers are grounded in what your organisation has taught it. This approach is called retrieval-augmented generation (RAG). The AI model itself does not change; what grows is the knowledge it can draw on, which is safer, faster and fully under your control.

ZAI updates itself: when a new version is published at zai.zyeemzia.com, the admin presses Update now in Settings, and ZAI downloads, verifies and installs it while keeping everything it has learned. Every official ZAI is sealed with fingerprints; a changed copy shows that it is not genuine and repairs itself from the official package when online.

Everything stays on the host computer: knowledge, conversations, formats, coworkers, pictures, settings and backups live in the data folder. ZAI backs itself up every day and keeps the last seven backups; Settings has Back up now, Restore and reset options, and a safety backup is made before every restore or reset.

ZAI was created by Zyeem Bin Zia, owner, founder and CEO of ZyeemZia. Website: zai.zyeemzia.com. Copyright ZyeemZia.
