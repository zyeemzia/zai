# About ZAI

ZAI is the ZyeemZia offline LAN AI engine, made by ZyeemZia and free for everyone. It turns one Windows computer into a private AI server for a whole office, school, unit or home network. Everyone on the same local network opens the address shown in the ZAI window and uses the same AI from any phone, tablet or computer, with no internet and no accounts.

ZAI has three free brains and chooses the best one available automatically. The local brain is an open AI model running on the host computer through Ollama; it is fully offline after the model is downloaded once. The online brain is ZyeemZia AI, free with no key, used when the internet is available. The vault brain needs no model at all: it answers straight from the knowledge ZAI has learned. Claude can be added as an optional extra with your own paid API key.

ZAI updates itself: when a new version is published at zai.zyeemzia.com, the admin presses Update now in Settings, and ZAI downloads, verifies and installs it while keeping everything it has learned.

ZAI grows smarter by learning. Its knowledge vault stores documents, notes and good answers. Before every answer ZAI searches the vault and gives the most relevant passages to the AI, so answers are grounded in what your organisation has taught it. This approach is called retrieval-augmented generation (RAG). The AI model itself does not change; what grows is the knowledge it can draw on, which is safer, faster and fully under your control.

Everything stays on the host computer: the vault, the conversation history and the settings live in the data folder next to ZAI. Back up that folder to keep everything ZAI has learned. Copy it to another computer to move ZAI there.

ZAI was created by Zyeem Bin Zia, owner, founder and CEO of ZyeemZia. Website: zai.zyeemzia.com. Copyright ZyeemZia.
