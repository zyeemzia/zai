# Modern AI ideas

## Large language models
A large language model (LLM) is a neural network trained on very large amounts of text to predict the next token. From that one skill it learns to answer questions, write, translate, summarise, reason step by step and write code. Open-weight models such as Qwen, Llama, Mistral and Gemma can run on your own computer; closed models such as Claude run in the cloud.

## Tokens and context
Models read text as tokens, pieces of words. The context window is how much text a model can consider at once, including the conversation and any documents given to it. Longer context lets a model use more knowledge in one answer but costs more time and memory.

## Retrieval-augmented generation (RAG)
RAG keeps knowledge outside the model in a searchable store. For each question, the system retrieves the most relevant passages and gives them to the model with the question. Benefits: answers stay current, sources can be shown, private data never needs to be trained into a model, and knowledge can be added or removed instantly. ZAI is built on RAG.

## Embeddings and vector search
An embedding turns text into a list of numbers so that passages with similar meaning are close together. Vector databases search by meaning rather than exact words. Keyword search such as BM25 ranks passages by matching words and is fast, transparent and works offline with no extra models; many systems combine both, called hybrid search.

## Agents
An AI agent is a model that can plan and use tools: search, calculators, databases, code execution or other programs, and loop until a task is done. Good agents have clear tools, limits on what they may do, and a human check before anything irreversible.

## Prompting well
Be specific about the goal, the audience and the format. Give the relevant facts. Ask for steps when a task is complex. Provide an example of a good answer. Ask the model to say when it is unsure.

## Fine-tuning versus RAG
Fine-tuning changes a model's weights by training on examples, useful for style or a narrow task, but it is slow, costly and hard to undo. RAG adds knowledge without retraining. For an organisation's facts and documents, RAG is usually the right first choice.

## Evaluating AI
Keep a set of real questions with known good answers and test against it whenever the model, the prompt or the knowledge changes. Measure accuracy, whether sources were used, and failures.

## Safety and limits
Models can be confidently wrong, a failure called hallucination. Ground answers in sources, show citations, and have people verify anything important. Never put passwords or secrets into prompts, and keep sensitive data on systems you control.
