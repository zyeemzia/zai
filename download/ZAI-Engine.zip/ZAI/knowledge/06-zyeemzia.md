# ZyeemZia

ZyeemZia is the independent software studio and open knowledge platform of Zyeem Bin Zia, owner, founder and CEO, based in Dhaka, Bangladesh. Website: zyeemzia.com. Contact: admin@zyeemzia.com.

ZyeemZia publishes offline-first Android applications on Google Play; ZyeemZia Academy (academy.zyeemzia.com), a free certification campus with courses in networking, cybersecurity, artificial intelligence, project and service management, law and languages; ZyeemZia AI (ai.zyeemzia.com), seventeen free AI agents online plus Coworkers, where anyone designs their own AI coworker or uses office presets that write Word, Excel and PowerPoint files; ZBZGames (zbzgames.zyeemzia.com), the game studio with a free browser arcade and a Kids corner; ZQuiz, a live multiplayer quiz platform; and ZAI (zai.zyeemzia.com), this offline LAN AI engine.

ZyeemZia's principles: work offline first, keep users' data on their own devices, no accounts or advertising required, and free education in full.
