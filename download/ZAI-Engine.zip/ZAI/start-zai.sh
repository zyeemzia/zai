#!/usr/bin/env sh
# ZAI on Linux or macOS: sh start-zai.sh
cd "$(dirname "$0")" && exec python3 zai_server.py "$@"
