@echo off
title ZAI - ZyeemZia offline LAN AI
cd /d "%~dp0"
echo.
echo  Starting ZAI ...
echo.
rem Find Python: the "py" launcher first, then "python".
where py >nul 2>nul && (py -3 zai_server.py %* & goto end)
where python >nul 2>nul && (python zai_server.py %* & goto end)
echo  Python 3 was not found on this computer.
echo.
echo  1. Install Python 3 from https://www.python.org/downloads/windows/
echo     (tick "Add python.exe to PATH" during setup).
echo  2. Then double-click START-ZAI.bat again.
echo.
start "" https://www.python.org/downloads/windows/
:end
echo.
pause
