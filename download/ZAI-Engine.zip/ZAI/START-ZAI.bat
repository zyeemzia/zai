@echo off
title ZAI - ZyeemZia offline LAN AI
cd /d "%~dp0"
rem The installed ZAI opens through ZAI.exe, so its window shows the ZAI icon.
if exist "%~dp0ZAI.exe" if exist "%~dp0runtime\python.exe" (start "" "%~dp0ZAI.exe" %* & exit /b 0)
echo.
echo  Starting ZAI ...
echo.
rem The installed ZAI carries its own Python; an unzipped copy uses the one on this PC.
if exist "%~dp0runtime\python.exe" ("%~dp0runtime\python.exe" zai_server.py %* & goto end)
where py >nul 2>nul && (py -3 zai_server.py %* & goto end)
where python >nul 2>nul && (python zai_server.py %* & goto end)
echo  Python 3 was not found on this computer.
echo.
echo  1. Install Python 3 from https://www.python.org/downloads/windows/
echo     (tick "Add python.exe to PATH" during setup).
echo  2. Then double-click START-ZAI.bat again.
echo.
start "" https://www.python.org/downloads/windows/
:end
echo.
pause
