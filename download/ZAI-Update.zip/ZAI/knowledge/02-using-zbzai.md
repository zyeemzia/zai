# Using ZBZAI

## Installing ZBZAI
Download ZBZAI-Setup.exe from zbzai.zyeemzia.com and run it on the computer that will be the server. If Windows says it protected your PC, choose More info, then Run anyway. Accept the licence, pick a drive or folder (the default needs no administrator rights; Program Files does), choose desktop and Start menu shortcuts, and press Install. Python is built in. On Linux or macOS, unzip ZBZAI-Engine.zip and run start-zbzai.sh with Python 3.9 or newer.

## Starting ZBZAI
Open ZBZAI from the desktop or Start menu icon. A window opens and shows two addresses: one for this computer and one for the local network, for example http://192.168.1.20:8765/, plus the admin PIN. Share the network address with anyone on the same Wi-Fi or LAN. Keep the window open while ZBZAI is in use; closing it stops the server.

## Phones, tablets and other computers
ZBZAI runs on the ZBZAI computer; other devices use it over the local network, with no internet. Connect the phone or tablet to the same Wi-Fi or network as the ZBZAI computer, open Share in ZBZAI and scan the QR code with the phone camera, or type the address. To open ZBZAI like an app: on Android in Chrome, tap the menu, then Add to Home screen or Install app; on iPhone and iPad in Safari, tap Share, then Add to Home Screen. On the ZBZAI computer itself, press Install app in the top bar (Edge or Chrome) for a ZBZAI window with its own icon. Phones cannot run ZBZAI by themselves; ZBZAI must be open on the ZBZAI computer.

The first time, Windows may ask whether ZBZAI can use the network. Choose Private networks so other devices on the LAN can connect. If others cannot connect, check that the host computer's network is set to Private and that both devices are on the same network.

## Getting a local AI model
Run GET-LOCAL-MODEL.bat once while online. It installs a free open model through Ollama. Small (qwen2.5:3b, about 2 GB) runs on most computers without a graphics card. Medium (qwen2.5:7b) gives better answers with 16 GB of memory or a graphics card. Large (qwen2.5:14b) needs a strong graphics card. After that, ZBZAI runs fully offline, and so do its coworkers. ZBZAI finds installed models automatically.

## Chatting
Type a question and press Enter. While ZBZAI answers, the send button becomes Stop. Under each answer: Copy, Read aloud, Try again, Export and Learn this. The plus button opens New chat, Past chats, Ask about a file (Word, PDF or text) and Save this chat. The microphone button types what you say, in the voice typing language chosen in Settings. It keeps listening through short pauses and stops by itself when you finish. With no internet it still works: the ZBZAI computer turns your voice into text itself, using the speech recognition built into Windows, or Whisper after you run GET-WHISPER.bat once.

## Coworkers
Open Coworkers to pick an AI coworker: Word Writer, Excel Analyst, PowerPoint Builder, Database Designer, PDF Publisher, Email and Letter Assistant, Minutes Taker, Voice Narrator, Video Explainer, Data Cleaner, Translator, HR and Policy Drafter, Tutor or IT Helpdesk. Press Work with, and the chat works in that coworker's way until you close the Working with bar. Customise makes your own copy of a ready-made coworker; New coworker creates one from scratch with a name, role, instructions, starter prompts, best export and icon. Coworkers are shared with everyone on the network and use what ZBZAI knows. They write full answers with a local model (offline) or with ZyeemZia AI online.

## Exporting files
Press Export under an answer, or in Studio, and choose a format: Word (.docx), Excel (.xlsx), PowerPoint (.pptx), PDF, Access (.accdb, needs Microsoft Office on the ZBZAI computer), CSV, SQLite database, web page, Markdown, text, JSON, audio as WAV (Windows voices) or MP3, or a narrated video as MP4 (MP3 and MP4 need the free ffmpeg tool on the ZBZAI computer). Tables become spreadsheet sheets and database tables named after the heading above them; ## headings become slides. For Bangla or Arabic PDFs, use Print and Save as PDF.

## Teaching ZBZAI
Open Knowledge. Paste notes, procedures, manuals or facts and press Teach, or upload files: text, Markdown, CSV, JSON, HTML, Word (.docx) and PDF. Tick "This is a document format" to add a letter or memo layout to Studio's Template list. When an answer is good, press Learn this: ZBZAI keeps it and uses it in future answers. That is how ZBZAI becomes smarter day by day.

## ZBZAI Studio
Documents: choose a template or one of your own formats, fill in the fields and press Write it; edit, copy, print, save as Word or export in any format. Quick draft fills the template instantly with no AI. Save as my format turns any document into a template. Pictures: describe a picture, pick a style and press Create; made free online by ZyeemZia AI, or offline with a local Stable Diffusion, and kept in a shared gallery. Songs: give a topic, language, mood and style for an original song with chords.

## Settings and the admin PIN
The admin PIN is needed to change settings, remove knowledge, formats, coworkers or pictures, and for backup, restore and reset. After several wrong PINs in a row ZBZAI pauses PIN entry from that device for a minute, and it refuses changes sent by other websites. The administrator can limit teaching to the admin only. Appearance (theme, accent colour, text size, voice typing language, read-aloud speed, wide layout) is set per device.

## Online answers, free
When the computer is online and no local model is installed, ZBZAI answers with ZyeemZia AI for free, grounded in its knowledge vault. When the internet is unavailable, it switches back to the local model or the vault automatically. More brains are optional: Claude, ChatGPT, Gemini, DeepSeek, Groq, Mistral, Grok and OpenRouter. In Settings, open "more AI brains with your own keys", paste the key, choose that brain and save. A brain with a key also answers when the chosen one cannot, for example when the free allowance is used up. When online, ZBZAI also keeps an offline copy of the ZyeemZia AI knowledge library (public facts about the ZyeemZia sites) so answers know them with no internet; it refreshes by itself, is kept apart from what you taught, and can be switched off in Settings.

## Updating ZBZAI
When a new version is available, a banner appears. Open Settings, enter the admin PIN and press Update now; ZBZAI downloads the update, checks its fingerprint, installs it and restarts. Running a newer ZBZAI-Setup.exe also updates ZBZAI. Knowledge, conversations, formats, coworkers and settings are always kept.

## Backup, restore and reset
Settings, Backup and restore: Back up now saves one file with everything; download it to keep a copy elsewhere. ZBZAI also backs up automatically every day and keeps the last seven. Restore works from the list or from an uploaded backup file. Reset options clear conversations, restore default settings, return to the starter knowledge, or reset everything; a safety backup is made first, so every change can be undone.

## Uninstalling
Use Apps in Windows Settings, or Uninstall ZBZAI in the ZBZAI folder. You can keep what ZBZAI learned so a later install picks it up again.
