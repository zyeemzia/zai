# ZBZAI™ by ZyeemZia · Copyright © ZyeemZia · All rights reserved. Sealed file: any change makes this copy not genuine and ZBZAI restores the official file.
# ZBZAI's engine is compiled to native code (zai_core). Open ZBZAI with the ZBZAI icon.
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
try:
    import zai_core
except ImportError as e:
    print()
    print('  ZBZAI could not start: its engine needs the Python that comes with ZBZAI.')
    print('  Install ZBZAI with ZBZAI-Setup.exe from https://zbzai.zyeemzia.com and open it with the ZBZAI icon.')
    print('  (' + str(e) + ')')
    sys.exit(1)
if __name__ == '__main__':
    zai_core.main()
