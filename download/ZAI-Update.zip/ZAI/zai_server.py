# ZAI by ZyeemZia · Copyright © ZyeemZia · All rights reserved. Sealed file: any change makes this copy not genuine and ZAI restores the official file.
# ZAI's engine is compiled to native code (zai_core). Open ZAI with the ZAI icon.
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
try:
    import zai_core
except ImportError as e:
    print()
    print('  ZAI could not start: its engine needs the Python that comes with ZAI.')
    print('  Install ZAI with ZAI-Setup.exe from https://zai.zyeemzia.com and open it with the ZAI icon.')
    print('  (' + str(e) + ')')
    sys.exit(1)
if __name__ == '__main__':
    zai_core.main()
