@echo off
title ZBZAI - optional extras (PDF reading)
cd /d "%~dp0"
echo  Installs pypdf so ZBZAI can learn from PDF files. Run once while online.
where py >nul 2>nul && (py -3 -m pip install --upgrade pypdf & goto done)
python -m pip install --upgrade pypdf
:done
pause
