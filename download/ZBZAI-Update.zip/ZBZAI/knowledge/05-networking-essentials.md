# Networking essentials

## Addresses
An IP address identifies a device on a network. Private ranges used inside local networks are 10.0.0.0/8, 172.16.0.0/12 and 192.168.0.0/16. A subnet mask such as 255.255.255.0 (/24) defines which addresses are on the same local network. The default gateway is the router that connects the LAN to other networks.

## DHCP and DNS
DHCP hands out IP addresses automatically. DNS translates names into IP addresses. On a LAN with no internet, devices still reach each other directly by IP address, which is how ZBZAI works offline.

## Ports
A port number identifies a service on a device: 80 for HTTP, 443 for HTTPS, 22 for SSH, 3389 for Remote Desktop. ZBZAI listens on port 8765 by default. A firewall decides which ports may be reached.

## Troubleshooting a LAN connection
1. Check both devices are on the same network and subnet (ipconfig on Windows shows the address).
2. Ping the host computer's address from the other device.
3. Make sure the host's Windows network profile is Private and the firewall allows the application.
4. Open http://<host-address>:8765/ in a browser on the other device.

## The OSI model
Seven layers describe networking: physical, data link, network, transport, session, presentation and application. Most troubleshooting starts at the bottom: cable or Wi-Fi first, then IP addressing, then the service itself.
