# Cybersecurity essentials

## Passwords and accounts
Use long passphrases, a different one for every account, kept in a password manager. Turn on multi-factor authentication, preferably an authenticator app or a security key rather than SMS. Never share one-time codes: real banks, IT teams and services never ask for them.

## Phishing
Phishing messages create urgency, impersonate trusted senders and push you to click, pay or log in. Check the real sender address and link destination, and confirm unusual requests through a separate known channel. Report suspicious messages to IT.

## Updates and backups
Install security updates promptly for the operating system, browsers and applications. Follow the 3-2-1 backup rule: three copies, on two kinds of media, one kept offline or off-site. Test restoring a backup regularly; ransomware recovery depends on it.

## Networks
Change default router passwords, use WPA3 or WPA2 with a strong passphrase, keep router firmware updated, and put guests and smart devices on a separate network. On a LAN, mark the network as Private only when you trust it, and allow only the services you need through the firewall.

## Least privilege
Give each person only the access their work needs, use standard accounts for daily work and admin accounts only for administration, and remove access promptly when people leave.

## Incident response
If you suspect compromise: disconnect the device from the network, do not delete evidence, write down what happened and when, and report immediately. Change passwords from a clean device.
