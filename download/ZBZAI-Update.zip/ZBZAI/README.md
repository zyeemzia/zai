# ZBZAI · ZyeemZia offline LAN AI engine

Turn one Windows computer into a private AI server for your whole local network.
No internet, no accounts, nothing leaves the building. Free, by ZyeemZia.

## Install
- **Windows**: run **ZBZAI-Setup.exe** from https://zbzai.zyeemzia.com. Choose the drive and folder; Python is built in; no administrator rights needed. Open ZBZAI from the desktop or Start menu icon.
- **Linux / macOS / portable**: unzip ZBZAI-Engine.zip and run `sh start-zbzai.sh` (or **START-ZBZAI.bat** on Windows) with Python 3.9 or newer.

The ZBZAI window shows the network address, for example `http://192.168.1.20:8765/`, and the admin PIN.
Phones, tablets and other computers on the same Wi-Fi or LAN use ZBZAI in the browser: open **Share** in ZBZAI and scan the QR code, then add ZBZAI to the home screen to open it like an app. ZBZAI itself runs only on this computer. If Windows asks about the firewall, allow **Private networks**.

## Brains (chosen automatically)
| Brain | Needs | Notes |
|---|---|---|
| Local model | Ollama + a model (run **GET-LOCAL-MODEL.bat** once while online) | Fully offline afterwards. Coworkers work offline with it. |
| ZyeemZia AI | Internet | Free, no key. Used when online and no local model is installed. |
| Claude, ChatGPT, Gemini, DeepSeek, Groq, Mistral, Grok, OpenRouter (optional) | Internet + your own API key, added in Settings (Gemini and Groq have free tiers) | When chosen in Settings, and as a backup when the chosen brain cannot answer. |
| Knowledge vault | Nothing | Answers straight from what ZBZAI has learned. Always available. |

If a brain fails, ZBZAI falls back to the next one by itself.

## Coworkers
Fourteen ready-made AI coworkers (Word writer, Excel analyst, PowerPoint builder, database designer, PDF publisher, email and letters, minutes, voice narrator, video explainer, data cleaner, translator, HR and policy, tutor, IT helpdesk), plus your own: name, role, instructions, starter prompts, best export and icon. Shared on the network.

## Export to any format
Every answer and Studio document exports to **Word, Excel, PowerPoint, PDF, CSV, SQLite, web page, Markdown, text and JSON**, all offline.
On Windows also **Access** (.accdb, with Microsoft Office installed) and **audio** (WAV) with the built-in voices; with the free **ffmpeg** tool, **MP3** audio and narrated **MP4** video.

## ZBZAI Studio
- **Documents**: templates and your own formats; **Write it** with AI or **Quick draft** with none; copy, print, Word or any export.
- **Pictures**: free online through ZyeemZia AI, or offline with a local Stable Diffusion WebUI or Forge (`--api`, port 7860). Saved in `data/images` and shared in the gallery.
- **Songs**: original lyrics with chords, key, tempo and strumming.

## How ZBZAI grows
ZBZAI learns through its **knowledge vault** (retrieval-augmented generation):
- **Knowledge → Teach**: paste notes, procedures, manuals, facts (tick *document format* to add a template).
- **Knowledge → Upload**: .txt .md .csv .json .html .docx .pdf.
- **Learn this** on a good answer: ZBZAI keeps it for the future.
- Starter knowledge in the `knowledge` folder is learned on first start.

## Updates, genuine copy
When online, ZBZAI checks zbzai.zyeemzia.com for new versions: **Update now** in Settings (admin PIN), or run a newer ZBZAI-Setup.exe. The `data` folder is never touched.
Every official ZBZAI is sealed: a changed copy shows it is not genuine and repairs itself from the official package when online.

## Backup, restore, reset
Settings → **Backup and restore** (admin PIN): back up now, download, restore from a file, and reset options. Automatic daily backups (last 7 kept) and a safety backup before every restore or reset. Everything lives in the `data` folder.

## Requirements
Windows 10 or 11 (setup includes Python). Linux and macOS: Python 3.9 or newer.
A local model needs about 4 GB free memory for the small model; a graphics card makes larger models fast.

See LICENSE.txt. Website: https://zbzai.zyeemzia.com

Copyright © ZyeemZia
