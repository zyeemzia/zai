@echo off
title ZBZAI - enable the optional cloud brain (Claude)
cd /d "%~dp0"
echo.
echo  Optional. Claude already works in ZBZAI with just your API key in Settings.
echo  This only adds Anthropic's official Python library, which ZBZAI uses when present.
echo  Run it once while connected to the internet.
echo.
where py >nul 2>nul && (py -3 -m pip install --upgrade anthropic & goto done)
python -m pip install --upgrade anthropic
:done
echo.
echo  Done. Add your API key in ZBZAI: Settings, then restart START-ZBZAI.bat.
pause
