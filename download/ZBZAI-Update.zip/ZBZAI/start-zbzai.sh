#!/usr/bin/env sh
# ZBZAI on Linux or macOS: sh start-zbzai.sh
cd "$(dirname "$0")" && exec python3 zbzai_server.py "$@"
