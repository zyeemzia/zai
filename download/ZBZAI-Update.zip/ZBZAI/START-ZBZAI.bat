@echo off
title ZBZAI - ZyeemZia offline LAN AI
cd /d "%~dp0"
rem The installed ZBZAI opens through ZBZAI.exe, so its window shows the ZBZAI icon.
if exist "%~dp0ZBZAI.exe" if exist "%~dp0runtime\python.exe" (start "" "%~dp0ZBZAI.exe" %* & exit /b 0)
echo.
echo  Starting ZBZAI ...
echo.
rem The installed ZBZAI carries its own Python; an unzipped copy uses the one on this PC.
if exist "%~dp0runtime\python.exe" ("%~dp0runtime\python.exe" zbzai_server.py %* & goto end)
where py >nul 2>nul && (py -3 zbzai_server.py %* & goto end)
where python >nul 2>nul && (python zbzai_server.py %* & goto end)
echo  Python 3 was not found on this computer.
echo.
echo  1. Install Python 3 from https://www.python.org/downloads/windows/
echo     (tick "Add python.exe to PATH" during setup).
echo  2. Then double-click START-ZBZAI.bat again.
echo.
start "" https://www.python.org/downloads/windows/
:end
echo.
pause
