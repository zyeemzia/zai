@echo off
title ZBZAI - get a local AI model (fully offline afterwards)
echo.
echo  ZBZAI's local brain uses Ollama, a free program that runs open AI models
echo  on this computer. Do this once while online; afterwards no internet is needed.
echo.
where ollama >nul 2>nul || (
  echo  Ollama is not installed yet. Opening its download page...
  start "" https://ollama.com/download/windows
  echo  Install it, then run this file again.
  pause
  exit /b
)
echo  Choose a model size:
echo    1  Small   - qwen2.5:3b   (about 2 GB, runs on most PCs, no graphics card needed)
echo    2  Medium  - qwen2.5:7b   (about 5 GB, better answers, 16 GB RAM or a graphics card)
echo    3  Large   - qwen2.5:14b  (about 9 GB, best answers, a strong graphics card)
set /p pick=  Type 1, 2 or 3 and press Enter: 
set model=qwen2.5:3b
if "%pick%"=="2" set model=qwen2.5:7b
if "%pick%"=="3" set model=qwen2.5:14b
ollama pull %model%
echo.
echo  Done. Start ZBZAI with START-ZBZAI.bat: it finds the model automatically.
pause
