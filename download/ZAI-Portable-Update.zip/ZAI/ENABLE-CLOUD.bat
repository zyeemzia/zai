@echo off
title ZBZAI - enable the optional cloud brain (Claude)
cd /d "%~dp0"
echo.
echo  This installs Anthropic's official Python library so ZBZAI can use Claude
echo  when this computer is online. ZBZAI works fully offline without it.
echo  Run it once while connected to the internet.
echo.
where py >nul 2>nul && (py -3 -m pip install --upgrade anthropic & goto done)
python -m pip install --upgrade anthropic
:done
echo.
echo  Done. Add your API key in ZBZAI: Settings, then restart START-ZBZAI.bat.
pause
