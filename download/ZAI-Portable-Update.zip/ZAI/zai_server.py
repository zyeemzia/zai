# ZBZAI™ by ZyeemZia · Copyright © ZyeemZia · All rights reserved. Sealed file: any change makes this copy not genuine and ZBZAI restores the official file.
# The name is now ZBZAI: this starts zbzai_server.py, which tidies the old names away.
import os, runpy, sys
_here = os.path.dirname(os.path.abspath(__file__))
sys.argv[0] = os.path.join(_here, 'zbzai_server.py')
runpy.run_path(sys.argv[0], run_name='__main__')
